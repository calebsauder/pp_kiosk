from time import sleep
print "testing the Lock..."

while 1:
    print 'waiting'
    sleep(60)
